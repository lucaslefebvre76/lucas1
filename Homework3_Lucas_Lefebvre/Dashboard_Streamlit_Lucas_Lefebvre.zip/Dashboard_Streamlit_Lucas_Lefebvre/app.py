import streamlit as st
import pandas as pd
import datetime

# ==========================================
# Page configuration
# ==========================================
st.set_page_config(page_title="2024 Market Dashboard", layout="wide")
st.title("Time Analysis Dashboard")
st.markdown("Interactive dashboard exploring 2024 market transactions.")

# ==========================================
# Data loading and cleaning
# Using @st.cache_data for speed
# ==========================================
@st.cache_data
def load_data():
    # Load raw data
    fact_raw = pd.read_csv('account-statement-1-1-2024-12-31-2024.csv', sep=';')
    dim_sym_raw = pd.read_csv('symbols.csv', sep=';')
    
    # Basic cleaning (dropping empty rows and fixing uppercase/spaces)
    fact_raw = fact_raw.dropna(subset=['IDTransaction']).reset_index(drop=True)
    fact_raw['Symbol'] = fact_raw['Symbol'].str.upper().str.strip()
    dim_sym_raw['symbol'] = dim_sym_raw['symbol'].str.upper().str.strip()
    
    # Format the date column to datetime format
    fact_raw['Date'] = pd.to_datetime(fact_raw['Date'], dayfirst=True, format='mixed')
    
    # Merge the fact table with the symbol dictionary to get sector/industry info
    df_merged = fact_raw.merge(dim_sym_raw, left_on='Symbol', right_on='symbol', how='left')
    
    # Drop orphan transactions (symbols not found in the dictionary)
    df_merged = df_merged.dropna(subset=['symbol']).reset_index(drop=True)
    
    return df_merged

# Load the dataset
df = load_data()

# ==========================================
# Interactive filters (sidebar)
# ==========================================
st.sidebar.header("Filter Panel")

# Enforce the exact dates
start_of_year = datetime.date(2024, 1, 1)
end_of_year = datetime.date(2024, 12, 31)

# Create a date range slider/input with these specific dates
selected_dates = st.sidebar.date_input(
    "Select Date Range",
    value=(start_of_year, end_of_year),
    min_value=start_of_year,
    max_value=end_of_year
)

# Apply the filter if the user selected both a start and an end date
if len(selected_dates) == 2:
    start_date, end_date = selected_dates
    # Filter the dataframe using a date mask
    mask = (df['Date'].dt.date >= start_date) & (df['Date'].dt.date <= end_date)
    filtered_df = df.loc[mask]
else:
    filtered_df = df # Fallback if only one date is selected

# Display a metric in the sidebar
st.sidebar.metric(label="Total Transactions in Range", value=len(filtered_df))

# ==========================================
# Dashboard charts
# Every time the user changes the date, Streamlit re-runs this part
# ==========================================

# Chart 1: Line chart showing total transactions over time
st.subheader("Total number of transactions over time (BUY + SELL)")
# Group by exact date and count the number of transactions
transactions_over_time = filtered_df.groupby(filtered_df['Date'].dt.date)['IDTransaction'].count()
st.line_chart(transactions_over_time)

# Visual separator
st.markdown("---")

# Create 3 columns for the bar charts
col1, col2, col3 = st.columns(3)

# Chart 2: Top 3 traded symbols
with col1:
    st.subheader("Top 3 Traded Symbols")
    top_symbols = filtered_df['Symbol'].value_counts().head(3)
    st.bar_chart(top_symbols)

# Chart 3: Top 5 sectors
with col2:
    st.subheader("Top 5 Sectors")
    top_sectors = filtered_df['sector'].value_counts().head(5)
    st.bar_chart(top_sectors)

# Chart 4: Top 5 industries
with col3:
    st.subheader("Top 5 Industries")
    top_industries = filtered_df['industry'].value_counts().head(5)
    st.bar_chart(top_industries)